/*
 * HomePage
 *
 * This is the first thing users see of our App, at the '/' route
 */

import React from "react"
import { Helmet } from "react-helmet"

const HomePage = () => (
  <article>
    <Helmet>
      <title>Home Page</title>
      <meta
        name="description"
        content="A React.js Boilerplate application homepage"
      />
    </Helmet>
    <div
      style={{
        fontFamily: "var(--MINEO-proxima-nova)",
        color: "var(--MINEO-cardinal)"
      }}
    >
      dsfdf
    </div>
  </article>
)

export default HomePage
