MINEO WebApp

## Generating the Build

    1. npm run build:production (this is for production)
    2. npm run build (This is for developement)

## Start the Project

    1. npm run start (for development)
    2. npm run start:prod (for production (first run "npm run build:production") )
